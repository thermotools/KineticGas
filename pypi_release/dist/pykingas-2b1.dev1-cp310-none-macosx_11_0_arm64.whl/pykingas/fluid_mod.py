import json
import os

def add_param_set(new_f, pset, old_f):
    params = old_f['q-Mie'][pset]
    fh_key = f'Mie-FH{params["FH_order"]}'
    if fh_key in new_f.keys():
        new_f[fh_key][pset] = old_f['q-Mie'][pset]
    else:
        new_f[fh_key] = {}
        new_f[fh_key]['default'] = old_f['q-Mie'][pset]
    return new_f


fluid_dir = os.path.dirname(__file__) + '/fluids'
files = os.listdir(fluid_dir)
fh_has_default = [False, False, False]
for file in files:
    print(file)
    fluid = json.load(open(f'{fluid_dir}/{file}', 'r'))
    new_fluid = {}
    for k in fluid.keys():
        if k == 'default_fh_order':
            continue
        
        if k == 'mol_weight':
            new_fluid[k] = fluid[k]
            new_fluid['default_fh_order'] = 0
            continue

        if k == 'Mie-FH1':
            fluid['default_fh_order'] = 1
        
        new_fluid[k] = fluid[k]

    json.dump(new_fluid, open(f'{fluid_dir}/{file}', 'w'), indent=4)